const loadRecordsButtonEl = document.getElementById("load-records");
const recordsListElement = document.getElementById("list");
const baseListItemRecord = document.querySelector("#list .record:nth-child(1)");

const baseUrl = `http://localhost:3030/jsonstore/records`;

const addRecordButtonEl = document.getElementById("add-record");
const editRecordButtonEl = document.getElementById("edit-record");

const nameInput = document.getElementById("p-name");
const stepsInput = document.getElementById("steps");
const caloriesInput = document.getElementById("calories");

let currentRecordId = null;

// Helper function to fetch data
async function fetchData(url, options) {
    try {
        const response = await fetch(url, options);
        if (!response.ok) {
            throw new Error(await response.text());
        }
        const data = await response.json();
        return { data, error: null };
    } catch (error) {
        console.error(error);
        return { data: null, error };
    }
}

// Load Records
function loadButtonHandler() {
    fetchData(baseUrl, base_fetch_options).then(({ data, error }) => {
        if (error) {
            return;
        }

        // Clear existing records before appending new ones
        recordsListElement.innerHTML = '';

        const records = Object.values(data);

        records.forEach((record) => {
            const { name, steps, calories, _id } = record;
        
            const clone = baseListItemRecord.cloneNode(true);

            clone.querySelector(".info p:nth-child(1)").textContent = name;
            clone.querySelector(".info p:nth-child(2)").textContent = steps;
            clone.querySelector(".info p:nth-child(3)").textContent = calories;

            clone.dataset.id = _id;

            clone.querySelector(".change-btn").addEventListener("click", changeButtonHandler);
            clone.querySelector(".delete-btn").addEventListener("click", deleteButtonHandler);

            recordsListElement.appendChild(clone);
        });
    });
}

// Add Record
function createRecordHandler() {
    const name = nameInput.value.trim();
    const steps = stepsInput.value.trim();
    const calories = caloriesInput.value.trim();

    // Ensure input validation
    if (!name || !steps || !calories) {
        alert("Please fill in all fields.");
        return;
    }

    const newRecord = {
        name,
        steps: Number(steps),
        calories: Number(calories)
    };

    fetch(baseUrl, {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
        },
        body: JSON.stringify(newRecord)
    }).then(() => {
        loadButtonHandler(); // Reload the records
        nameInput.value = '';
        stepsInput.value = '';
        caloriesInput.value = '';
    }).catch(error => {
        console.error('Error adding record:', error);
    });
}

// Populate input fields for editing
function changeButtonHandler(event) {
    const recordElement = event.target.closest(".record");
    const name = recordElement.querySelector(".info p:nth-child(1)").textContent;
    const steps = recordElement.querySelector(".info p:nth-child(2)").textContent;
    const calories = recordElement.querySelector(".info p:nth-child(3)").textContent;

    nameInput.value = name;
    stepsInput.value = steps;
    caloriesInput.value = calories;

    currentRecordId = recordElement.dataset.id;

    addRecordButtonEl.disabled = true;
    editRecordButtonEl.disabled = false;
}

// Edit Record
function editRecordHandler() {
    const updatedRecord = {
        name: nameInput.value.trim(),
        steps: Number(stepsInput.value.trim()),
        calories: Number(caloriesInput.value.trim()),
    };

    fetch(`${baseUrl}/${currentRecordId}`, {
        method: "PUT",
        headers: {
            "Content-Type": "application/json",
        },
        body: JSON.stringify(updatedRecord)
    }).then(() => {
        loadButtonHandler(); // Reload the records
        nameInput.value = '';
        stepsInput.value = '';
        caloriesInput.value = '';
        addRecordButtonEl.disabled = false;
        editRecordButtonEl.disabled = true;
    });
}

// Delete Record
function deleteButtonHandler(event) {
    const recordElement = event.target.closest(".record");
    const recordId = recordElement.dataset.id;

    fetch(`${baseUrl}/${recordId}`, {
        method: "DELETE",
        headers: {
            "Content-Type": "application/json",
        },
    }).then(() => {
        loadButtonHandler(); // Reload the records
    });
}

// Event Listeners
loadRecordsButtonEl.addEventListener("click", loadButtonHandler);
addRecordButtonEl.addEventListener("click", createRecordHandler);
editRecordButtonEl.addEventListener("click", editRecordHandler);

// Initialize the form state
addRecordButtonEl.disabled = false;
editRecordButtonEl.disabled = true;
